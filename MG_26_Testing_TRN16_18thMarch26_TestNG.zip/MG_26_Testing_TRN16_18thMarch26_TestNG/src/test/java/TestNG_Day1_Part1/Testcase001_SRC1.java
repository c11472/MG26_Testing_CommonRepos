package TestNG_Day1_Part1;

import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Test;

import TestNG_Day1_Annotations.ConditionsTestNG;

public class Testcase001_SRC1 extends ConditionsTestNG {
  @Test(priority=1)
  public void f() {
	  System.out.println("I am eating Icecream ");
	   
}
  @Test(priority=3)
  public void f2() {
	  System.out.println("I am eating Biriyani ");
	   
}
  @Test(priority=2)
  public void f3() {
	  System.out.println("I am drinking tea ");
	   
}
  //@Ignore
  @Test
  public void cat() {
	  System.out.println("hello world !");
  }
  
  @Test
  public void apple() {
	  int arr[] = {1,2,3,4,5};
	  for(int i:arr) {
		  System.out.println(i + " ");
	  }
  }
  
 }
