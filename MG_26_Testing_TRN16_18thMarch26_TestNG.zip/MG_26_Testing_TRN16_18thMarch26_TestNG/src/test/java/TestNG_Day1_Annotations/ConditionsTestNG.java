package TestNG_Day1_Annotations;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ConditionsTestNG {
	 @BeforeTest
	  public void test_pre() {
		  System.out.println("pre condition - test level");
	  }
	  
	  @AfterTest
	  public void test_post() {
		  System.out.println("post condition - test level");
	  }
	  
	  @BeforeClass
	  
	  public void test_preClass() {
		  System.out.println("pre condition - class level");
	  }
	  
	  
	  
	  
	  @AfterClass
	  
	  public void test_postClass() {
		  System.out.println("post condition - class level");
	  }
	  
	  
	  @BeforeMethod
	  
	  public void test_preMethod() {
		  System.out.println("pre condition - method level");
	  }
	  
	  
	  @AfterMethod
	  
	  public void test_postMethod() {
		  System.out.println("post condition - method level");
	  }
	  
	  
	  @BeforeSuite
	  public void test_preSuite() {
		  System.out.println("pre condition - suite level");
	  }
	
	  
	  @AfterSuite
	  public void test_postSuite() {
		  System.out.println("post condition - suite level");
	  }
	

}

