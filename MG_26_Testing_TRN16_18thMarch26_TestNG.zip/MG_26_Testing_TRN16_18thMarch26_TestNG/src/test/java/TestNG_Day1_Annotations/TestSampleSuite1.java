package TestNG_Day1_Annotations;

import org.testng.annotations.Test;

public class TestSampleSuite1 {
  @Test
  public void f() {
	  System.out.println("hello suite !");
  }
}
