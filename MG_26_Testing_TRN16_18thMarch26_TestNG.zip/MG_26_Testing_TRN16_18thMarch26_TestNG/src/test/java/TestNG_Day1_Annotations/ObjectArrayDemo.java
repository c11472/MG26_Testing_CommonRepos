package TestNG_Day1_Annotations;

public class ObjectArrayDemo {
	public static void main(String[] args) {
		
		Object empDetails[] = {"amit",11472,72000.00};
		
		for(Object i:empDetails) {
			System.out.println(i);
		}
		
	}

}
