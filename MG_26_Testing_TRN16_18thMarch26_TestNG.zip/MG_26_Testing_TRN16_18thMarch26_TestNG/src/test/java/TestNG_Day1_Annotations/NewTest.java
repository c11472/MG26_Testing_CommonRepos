package TestNG_Day1_Annotations;

import org.testng.annotations.Test;

public class NewTest {
  @Test
  public void f() {
  }
}
