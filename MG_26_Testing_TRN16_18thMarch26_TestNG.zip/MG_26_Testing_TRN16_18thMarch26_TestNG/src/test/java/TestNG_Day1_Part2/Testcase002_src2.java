package TestNG_Day1_Part2;

import org.testng.annotations.Test;

import TestNG_Day1_Annotations.ConditionsTestNG;

public class Testcase002_src2 extends ConditionsTestNG {
  @Test
  public void f() {
	  System.out.println("test data ");
  }
}
