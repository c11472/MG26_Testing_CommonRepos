package TestNG_Day1_Part3_DataProvider;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class DBTest001 {
  @Test(dataProvider = "dp1") // dataProvider property
  public void PerformLogin(String  userName, int passWord) {
	   System.out.println("the user name is : " + userName);
	   System.out.println("the password is : "+ passWord);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "user001", 1176 },
      new Object[] { "user002", 1153 },
      new Object[] { "user003", 1163 }
    };
  }
//    @Test(dataProvider = "dp1") // dataProvider property
//    public void PerformLogin2(String  userName1, int passWord1) {
//  	   System.out.println("the user name is : " + userName1);
//  	   System.out.println("the password is : "+ passWord1);
//    }

    
    @DataProvider
    public Object[][] dp1() {
      return new Object[][] {
        new Object[] { "user011", 1178 },
        new Object[] { "user022", 1158 },
        new Object[] { "user023", 1169 }
      };
   
    }
}
