package TestNG_Day2_ReportssAndAssertions;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

public class TC001_NG1 {
  @Test
  public void DiplayArray() {
	  
	  int arr[] = {1,2,3,4,5,6};
	  for(int i:arr) {
		  System.out.print(i+ " ");
	  }
	  
  }
  
  @Test
  public void ListDataEid() {
	  List<Integer> EmpIDList =
			  Arrays.asList(1111,1222,1333,1444);
	  System.out.println(EmpIDList);
  }
  
  
  @Test
  public void ReverseMyName() {
	  String name="Gayatri";
	  StringBuffer sb = new StringBuffer(name);
	  StringBuffer revsb = sb.reverse();
	  System.out.println(revsb);
  }
  
  @Test
  public void DoNotExecute() {
	  System.out.println("Do not execute !")
  }
}
