package DesignPatternTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;


import Pages_lib2_sample.page2;
import Pages_lib_sample.page1;
import UtilityPackCommon.BaseUtilityMethods;

public class TestCase001 {
	
	
  WebDriver driver;
  //String
  String baseUrl = "https://www.selenium.dev/";
  
  //page objects
  
  BaseUtilityMethods util=new BaseUtilityMethods();
  page1 pg1 = new page1();
  page2 pg2 = new page2();

  @BeforeTest
  public void setup() throws InterruptedException {
	  util.init_BaseUtilityMethods(driver);
	  util.open_browser();
	  util.Sleep_Timmer(2000);
	  util.maximize_browser();
	  util.Sleep_Timmer(2000);
	  util.launchapp(baseUrl);
	  
  }
  
  @Test(priority=1)
  public void Test_Page1() {
	  pg1.initpage1(driver);
	  String dataValPage1=pg1.Extract_Data_HomePage();
	  System.out.println(dataValPage1);
	  pg1.Click_Documentation();
  }
  
  @Test(priority=2)
  public void Test_Page2() {
	  pg2.init_page2(driver);
	  String actval=pg2.Extract_Data_From_Doc_Page();
	  System.out.println(actval);
  }
  
  @AfterTest
  public void teardown() {
	//  util.init_BaseUtilityMethods(driver);
	//  util.browse_quit();
}
  
}
