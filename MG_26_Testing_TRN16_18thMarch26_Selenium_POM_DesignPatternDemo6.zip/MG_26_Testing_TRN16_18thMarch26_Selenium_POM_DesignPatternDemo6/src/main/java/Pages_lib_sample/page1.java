package Pages_lib_sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page1 {
	
	// Declaration of WebDriver
	// We should not instantiate the browser drivers in page class
	
	WebDriver driver;

	// By elements
	
	By textLoc1 = By.xpath("//*[@class='d-1 fw-bold']");
	
	By txtdoc2= By.xpath("//span[contains(text(),'Documentation')]");
	
	
	// init method
	
	public void initpage1(WebDriver driver) {
		this.driver=driver;
		
	}
	
	public String Extract_Data_HomePage() {
		String dataval=driver.findElement(textLoc1).getText();
		return dataval;
	}
	
	public void Click_Documentation() {
		driver.findElement(txtdoc2).click();
	}
	
	
	
	
	
	
	
	

	
}
