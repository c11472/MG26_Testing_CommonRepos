package Pages_lib2_sample;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class page2 {
	WebDriver driver;
	
	By docloc3 = 
			By.xpath("//h1[contains(text(),'The Selenium Browser Automation Project')]");
	
	public void init_page2(WebDriver driver)  {
		this.driver=driver;
		
	}
	
	
	public String Extract_Data_From_Doc_Page() {
		String docpage2text=driver.findElement(docloc3).getText();
		return docpage2text;
	}
	
	
	
	
	

}
