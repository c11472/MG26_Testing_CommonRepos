package UtilityPackCommon;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseUtilityMethods {
	
	WebDriver driver ;
	
	
	public void init_BaseUtilityMethods (WebDriver driver) {
		this.driver=driver;
		
	}
	
	public void open_browser() {
		driver = new ChromeDriver();
	}
	
	
	
	
	public void maximize_browser() {
		
		driver.manage().window().maximize();
	}
	
	public void launchapp(String url) {
		driver.get(url);
		
	}
	
	public void navigate_back() {
		
	}
	
	public void navigate_forward() {
		
	}
	
	public void navigate_refresh() {
		
	}
	
	public void Sleep_Timmer(int timeamt) throws InterruptedException {
		
		Thread.sleep(timeamt);
		
	}
	
	public void Implici_Wait(int timeamtimp) {
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeamtimp));
		
	}
	
	public void Explici_Wait(int timeamtexp) {
		
	}
	
	public void browse_quit() {
		driver.quit();
		
	}
	

}
