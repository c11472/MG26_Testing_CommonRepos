package Awesome_Test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import Awesome_Lib.Login_Invalid;
public class Test_Login_Invalid {
	WebDriver driver = new ChromeDriver();
	Login_Invalid test1 = new Login_Invalid();
	String exp_err_login = "Warning: No match for E-Mail Address and/or Password.";
	
  @BeforeTest
  public void Invoke_Login_Form() {
	  test1.init(driver);
	  driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
  }
  @Test
  
  public void login_invalid_test() {
	  
	  String act_invalid_login_err = 
			  test1.Validate_InValid_Login("testuser56", "testuser56");
	  System.out.println(act_invalid_login_err);
	  
	   Assert.assertEquals(exp_err_login, act_invalid_login_err);
  }
  
  
}
