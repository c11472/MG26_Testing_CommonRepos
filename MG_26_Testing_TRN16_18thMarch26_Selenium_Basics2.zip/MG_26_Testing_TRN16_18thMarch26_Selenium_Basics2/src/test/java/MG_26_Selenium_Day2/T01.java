package MG_26_Selenium_Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class T01 {
	
  WebDriver driver = new ChromeDriver();
  @Test
  public void LaunchApp() {
	  System.out.println("hello");
	  
	  driver.navigate().to("https://awesomeqa.com/ui/index.php?route=account/register");
	  
	 // driver.findElement(By.id("input-firstname")).sendKeys("testdata567");
	  
	  // to locate first name
	  
	 // driver.findElement(By.xpath("//*[@id='input-firstname']")).sendKeys("usernamefirst123");
	  driver.findElement(By.name("firstname")).sendKeys("yessssssss56");
	  
	  
		  

	 /* By.id(null)
	  By.name()
	  By.xpath(null)
	  By.cssSelector(null)
	  By.className(null)
	  By.linkText(null)
	  By.partialLinkText(null)*/
	  
	  
	  
  }
}
