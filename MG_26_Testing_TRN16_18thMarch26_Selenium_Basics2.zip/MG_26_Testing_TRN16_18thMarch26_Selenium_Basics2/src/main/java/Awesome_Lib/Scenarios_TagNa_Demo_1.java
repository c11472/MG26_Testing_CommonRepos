package Awesome_Lib;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class Scenarios_TagNa_Demo_1 {
	//  declare WebDriver Object
	WebDriver driver;
	// init method
	public void init_home(WebDriver driver) {
		this.driver=driver;
			}
	   
	// method to count the links
	public int Count_Links_In_Login_Page(String UrlLogin)
	{
		driver.get(UrlLogin);
		List<WebElement> ListLinks = driver.findElements(By.tagName("a"));
		int CountLinks = ListLinks.size();
		return CountLinks;
		
	}
	
	
	public void NameList_Links_In_Login_Page(String UrlLogin)
			throws InterruptedException
	{
		driver.get(UrlLogin);
		List<WebElement> ListLinks = driver.findElements(By.tagName("a"));
		int CountLinks = ListLinks.size();
		
		for(int i=0;i<=CountLinks-1;i++) {
			String NameList = driver.findElements(By.tagName("a")).get(i).getText();
			System.out.println(NameList);
			Thread.sleep(50);
		}
		//return CountLinks;
		
	}
	}



































