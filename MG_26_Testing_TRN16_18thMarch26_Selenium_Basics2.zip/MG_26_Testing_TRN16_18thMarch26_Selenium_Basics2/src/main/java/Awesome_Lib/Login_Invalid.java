package Awesome_Lib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login_Invalid {
	
	WebDriver driver;
	
	public void init(WebDriver driver) {
		this.driver=driver;
		
	}
	
	
	
	
	public String Validate_InValid_Login(String email , String password) {
		//driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
		driver.findElement(By.name("email")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(password);
		
		driver.findElement(By.xpath("//*[@type='submit']")).click();
		
		
		String msg_exp_invalid = driver
				.findElement(By.xpath("//*[contains(text(),' Warning: Your account has exceeded allowed number of login attempts. Please try again in 1 hour.')]"))
				.getText();
		return msg_exp_invalid;
	}
	

}
