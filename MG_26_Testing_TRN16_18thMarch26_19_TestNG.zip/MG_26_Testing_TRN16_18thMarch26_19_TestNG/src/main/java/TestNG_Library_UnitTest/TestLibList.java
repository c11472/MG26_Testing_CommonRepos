package TestNG_Library_UnitTest;

import java.util.Arrays;
import java.util.List;

public class TestLibList {
	
	public List<String> ListOfEmpName() {
		
		List <String> NameList =
				Arrays.asList("Amit", "Mohan","Rajeswari" ,"Rahul","Irfhan","Rashmitha");
	    return NameList;
		
	}
	
	
	public List<Integer> ListOfID(){
		List<Integer> IdList = Arrays.asList(1147,5643,2700,1181,2908,3675);
		return IdList;
	}
	
	public List<Double> ListSal(){
		List<Double> SalList = Arrays.asList(45000.50 ,32000.25 ,31000.75,49000.45,67000.56 , 39000.80);
		return SalList;
	}
	
	
	public boolean CheckTest(String nm , String nm1) {
		boolean res=nm.equals(nm1);
		return res;
	}
	
	public int[] CheckArray() {
		int arr[] = {1,2,3,4,5};
		return arr;
		
	}
	
	

}
