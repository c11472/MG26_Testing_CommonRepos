package Access_TestNG_Library_UnitTest;

import static org.testng.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import TestNG_Library_UnitTest.TestLibList;
import junit.framework.Assert;

public class AccessTestLibList {
	
  // Object creation
	
	TestLibList testlib = new TestLibList();
	
	
	//Expected Data Containers	
	List<String> Exp_NameList  = Arrays.asList("Amit", "Raghu","Rajeswari" ,"Rahul","Irfhan","Rashmitha");
    List<Integer> Exp_IdList = Arrays.asList(1147,5643,2700,1181,2908,3675);
    List<Double> Exp_SalList = Arrays.asList(45000.50 ,32000.25 ,31000.75,49000.45,67000.56 , 39000.80);
    
    boolean expCheck =false;
    int expArr[] = {1,2,3,4,5};
  @Test(priority=1)
  public void EmpNameDetailsCheck() {
	 List <String> act_EmpName =  testlib.ListOfEmpName();
	 System.out.println("Actual act_EmpNameList" + act_EmpName);
	 Assert.assertEquals(Exp_NameList, act_EmpName);

	  }
  
  @Test(priority=2)
  public void EmpIDCheck() {
	  List <Integer> act_eid = testlib.ListOfID();
	  System.out.println("Actual act_id" + act_eid);
	  Assert.assertEquals(Exp_IdList, act_eid);
	  
  }
  
  @Test(priority=3)
  public void EmpSalCheck() {
	  List <Double> act_sal = testlib.ListSal();
	  System.out.println("Actual act_sal" + act_sal);
	  Assert.assertEquals(Exp_SalList, act_sal);

	  
	  
  }
  
  @Test(priority=4)
  public void CheckTest1() {
	boolean actCheck=  testlib.CheckTest("mumbai", "mumbai56");
	
	//Assert.assertTrue(actCheck);
	Assert.assertFalse(actCheck);
	
  }
  
  @Test(priority=5)
  public void ArrayCheck() {
	  
	int actArray[]=  testlib.CheckArray();
	
	Assert.assertEquals(expArr, actArray);
	
	
	//Assert.assertSame(expArr, actArray);
	//Assert.assertNotNull(actArray);
	//Assert.assertNull(actArray);
	
	
	
	  
  }
  
  
  @Test(priority=6)
  public void testSame() {
	  String expData = "testdata";
	  String actData = "testdata67";
	//  Assert.assertSame(actData, expData);
	  Assert.assertNotSame(expData, actData);
	  
  }
  
  @Test
  public void AssertTestNull() {
	  String num = "test56";
	  Assert.assertNotNull(num);
	  
  }
  
  
}
