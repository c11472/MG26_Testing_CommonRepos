package com.ExcelRead.Script;

import java.io.IOException;

import org.testng.annotations.Test;

import ExcelRead_POI.ExcelRead_POI.ExcelRead1;

public class Access_ExcelRead1 {
	
  // Object for ExcelReadOne class	
  ExcelRead1 obj = new ExcelRead1();
  @Test
  public void ReadDataFromExcel() throws IOException {
			
			
			String res=obj.ReadCellData(1, 2);
			System.out.println(res);

  }
}
