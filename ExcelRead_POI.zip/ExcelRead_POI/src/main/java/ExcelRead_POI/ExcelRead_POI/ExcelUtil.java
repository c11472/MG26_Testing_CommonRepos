package ExcelRead_POI.ExcelRead_POI;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.FileInputStream;

public class ExcelUtil {
	
	WebDriver driver;
	
	//driver = new ChromeDriver();
    static String filePath = "D:\\Java_Programming_2025_2026_Gayatri\\ExcelRead_POI\\TestData\\Login_Data.xlsx";
    static String sheetName = "Sheet1";
    public static Object[][] getLoginData(String filePath, String sheetName) throws Exception {


        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        int rowCount = sheet.getPhysicalNumberOfRows();
        int colCount = sheet.getRow(0).getPhysicalNumberOfCells();

        Object[][] data = new Object[rowCount - 1][colCount];

        for (int i = 1; i < rowCount; i++) {
            Row row = sheet.getRow(i);
            for (int j = 0; j < colCount; j++) {
                data[i - 1][j] = row.getCell(j).toString();
            }
        }
        
        System.out.println("hello");

        workbook.close();
        fis.close();

        return data;
    }
    
    
    
    
    public static void main(String[] args) throws Exception {
  /*  	ExcelUtil excdata = new ExcelUtil();
    	excdata.getLoginData(filePath,sheetName ); */
    	WebDriver driver= new ChromeDriver();
    	driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
    	
    	
    	
        String excelFilePath =
        		"D://Java_Programming_2025_2026_Gayatri//ExcelRead_POI//TestData//Login_Data.xlsx";
        FileInputStream fis = new FileInputStream(excelFilePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet("Sheet1");
       

        for (int i = 1; i <= sheet.getLastRowNum(); i++) {
            Row row = sheet.getRow(i);
            if (row == null) continue;
            Object username = row.getCell(0).getStringCellValue();
            Object password = row.getCell(1).getNumericCellValue();
            
            driver.findElement(By.id("input-email")).sendKeys(username.toString());
           // driver.findElement(By.id("input-email")).clear();
            driver.findElement(By.id("input-password")).sendKeys(password.toString());
           // driver.findElement(By.id("input-password")).clear();
            Thread.sleep(3000);
            
             driver.findElement(By.id("input-email")).clear();
             driver.findElement(By.id("input-password")).clear();
             Thread.sleep(1000);
             
             driver.findElement(By.xpath("//*[@type='submit']")).click();
             
             driver.navigate().back();
           // String username = row.getCell(0).getStringCellValue();
           // String password = row.getCell(1).getStringCellValue();
            //System.out.println(username + "****" +password);

        }

        workbook.close();
        fis.close();

		
	}
}
