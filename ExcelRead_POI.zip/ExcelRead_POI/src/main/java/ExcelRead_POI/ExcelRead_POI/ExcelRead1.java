package ExcelRead_POI.ExcelRead_POI;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead1 {
	
	public String ReadCellData(int vRow, int vColumn) throws IOException  
	{  
	String value=null;          //variable for storing the cell value  
	Workbook wb=null;           //initialize Workbook null  
 
	//reading data from a file in the form of bytes  
	FileInputStream fis=new FileInputStream("./TestData/data45.xlsx");  
	//constructs an XSSFWorkbook object, by buffering the whole stream into the memory  
	wb=new XSSFWorkbook(fis);  
	
	//wb.getSh
	Sheet sheet=wb.getSheetAt(0);   //getting the XSSFSheet object at given index  
	Row row=sheet.getRow(vRow); //returns the logical row  
	Cell cell=row.getCell(vColumn); //getting the cell representing the given column  
     
	value = cell.getStringCellValue();
	//cell.getNumericCellValue();  
	//cell.getDateCellValue();
	//cell.getHyperlink();
	//cell.getLocalDateTimeCellValue();
	
	
	return value;  
	//returns the cell value  
	} 
	
	
	
	
}

	
