package Alert_Lib;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Alert_Rediff
 {
	
	WebDriver driver;
	
	Alert act ;

	
	// init
	
	public void init_Alert_Rediff(WebDriver driver) {
		this.driver=driver;
		
	}
	
	// Invoke rediff login page
	
	public void Launch_Loginform(String BseURL) {
		driver.get(BseURL);

	}
	
	public void Enter_Email(String email) {
		driver.findElement(By.id("login1")).sendKeys(email);
	}
	
	public void Click_Submit() {
		driver.findElement(By.name("proceed")).submit();
	}
		
	// Create alert instance
	
	public String GetAlertMessage() throws InterruptedException {
		//act= driver.switchTo().alert();
		act = driver.switchTo().alert();
		String Alert_Message= act.getText();
		Thread.sleep(3000);
		return Alert_Message;
		
	}
	
	// Extract alert message
	
	public void Input_Alert() {
		
		act.sendKeys("Hi this is Gayatri ! ");
	}
	
	public void Cancel_Alert() {
		act.dismiss();
	}
	
	public void Accept_Alert() {
		act.accept();
	}
	
	
	
	

}
