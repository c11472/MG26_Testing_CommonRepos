package Select_Lib;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class MySelect_Lib {
	WebDriver driver;
	
	Select sel;
	
  // WebElement selCities = driver.findElement(By.id("cities"));
	
 //  Select sel = new Select(driver.findElement(By.id("cities")));
	// init method
	
    
	
	public void init_select(WebDriver driver) {
		this.driver=driver;
		
		
	}
	
	// Launch the html form
	
	public void Open_Form_Select(String BaseUrl) 
			throws InterruptedException {
		driver.get(BaseUrl);
		
		Thread.sleep(3000);
		
	}
	
	
	// 1. Single item selection
	// 2. Multiple Select
	// 3. Extract all elements
	// 4. Check a specific element is present in the list or not
	// 5. Validate the expected list with actual list
	// 6. Count the number of elements and validate with expected count
	
	public void CreateSelectInstance() {
		sel =
	    		new Select(driver.findElement(By.id("cities")));

		
	}
	public void Select_Single_Option(int index) throws InterruptedException {
      
		CreateSelectInstance();
		sel.selectByIndex(index);
		Thread.sleep(3000);
		
	}
	
	public void Multi_Select() {
		sel.selectByIndex(3);
		sel.selectByVisibleText("Delhi");
		sel.selectByValue("pune");
		
	}
	
	public List<WebElement> GetAllElements(){
		List<WebElement> selList_act = sel.getOptions();
		return selList_act;
	}

}
