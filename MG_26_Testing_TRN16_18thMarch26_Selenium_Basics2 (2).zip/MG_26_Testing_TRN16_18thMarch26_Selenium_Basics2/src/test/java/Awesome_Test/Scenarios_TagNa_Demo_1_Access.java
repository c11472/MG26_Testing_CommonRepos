package Awesome_Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import Awesome_Lib.Scenarios_TagNa_Demo_1;
import junit.framework.Assert;

public class Scenarios_TagNa_Demo_1_Access {
	WebDriver driver = new ChromeDriver();
	Scenarios_TagNa_Demo_1 test1 = new Scenarios_TagNa_Demo_1();
	String BaseUrl = "https://awesomeqa.com/ui/index.php?route=account/login";
	int expcount = 81;
  @Test
  public void CountLinksFromLoginPage() {
	  
	  test1.init_home(driver);
	  int linksCount= test1.Count_Links_In_Login_Page(BaseUrl);
	  System.out.println("No of links:" + linksCount);
	  
	  Assert.assertEquals(expcount, linksCount);
  }
  
  @Test(priority=2)
  public void NameListLinks() throws InterruptedException {
	 // test1.Count_Links_In_Login_Page(BaseUrl)
	  test1.NameList_Links_In_Login_Page(BaseUrl);
  }
}












