package Access_Alert_Lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import Alert_Lib.Alert_Rediff;

public class Access_Alert_Lib_Test { 
	WebDriver driver = new ChromeDriver();
	Alert_Rediff obj1 = new Alert_Rediff();
	String BaseLogin = "https://mail.rediff.com/cgi-bin/login.cgi";
	
  @Test
  public void Alert_Handle() throws InterruptedException {
	  
	  obj1.init_Alert_Rediff(driver);
	  
	  obj1.Launch_Loginform(BaseLogin);
	  
	  obj1.Enter_Email("gayatrimis3");
	  
	  obj1.Click_Submit();
	  
	  String message = obj1.GetAlertMessage();
	  System.out.println("The actual alert message is : " + " " +message );
	  // obj1.Cancel_Alert();
	  //obj1.Input_Alert();
	  
	  obj1.Accept_Alert();
	  
	  // obj1.Input_Alert();

  }
}
