package Access_Select_Lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SelectTest {
	public static void main(String[] args) {
		WebDriver driver =
				 new ChromeDriver();
		
		driver.get("file:///D:/MG26_Testing_TRN16/TestSelect.html");
	}

}
