package Access_Select_Lib;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Select_Lib.MySelect_Lib;

public class Access_Select {
 // WebDriver Object
	
	
	// Object of MySelect_Lib
	MySelect_Lib obj = new MySelect_Lib();
	WebDriver driver =
			new ChromeDriver();
	
	String Form_Select_Url= "file:///D:/MG26_Testing_TRN16/TestSelect.html";
	
  @Test(priority=1)
  public void Launch_Select_Form() throws InterruptedException {
		
	  
	
		obj.init_select(driver);

		String Form_Select_Url= "file://D://MG26_Testing_TRN16//TestSelect.html";

	  //obj.init_select(driver);
	  
	  obj.Open_Form_Select(Form_Select_Url);
	  
	  obj.Select_Single_Option(7);
	  
  }
  
  
  @Test(priority=2)
  public void Perform_Multiple_Select() {
	  obj.Multi_Select();
  }
  
  @Test(
)
  public void GetAllElementsFromList() {
	  
	 List<String> actData = new ArrayList();
	  
	 List<WebElement> ListOfElements_Act= obj.GetAllElements();
	  
	 for(int i=0;i<=ListOfElements_Act.size()-1;i++) {
		 String Elements = ListOfElements_Act.get(i).getText();
		 System.out.println(Elements);
		 actData.add(Elements);
	 }
  }
  
  
  
  
	
}
